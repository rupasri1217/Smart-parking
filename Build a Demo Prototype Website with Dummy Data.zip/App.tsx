import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import MapView from "./pages/MapView";
import BookingPage from "./pages/BookingPage";
import PaymentPage from "./pages/PaymentPage";
import HistoryPage from "./pages/HistoryPage";
import AdminDashboard from "./pages/AdminDashboard";
import ExtendCancelPage from "./pages/ExtendCancelPage";
import FeedbackPage from "./pages/FeedbackPage";
import ProfileSettingsPage from "./pages/ProfileSettingsPage";
import ActiveSessionPage from "./pages/ActiveSessionPage";
import { useAuth } from "./_core/hooks/useAuth";
import { Loader2 } from "lucide-react";

function Router() {
  const { isAuthenticated, loading, user } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  return (
    <Switch>
      {/* Home/Login routes */}
      <Route path={"/"} component={Home} />
      <Route path={"/home"} component={Home} />
      <Route path={"/login"} component={Home} />
      
      {isAuthenticated && (
        <>
          {/* Admin can access admin dashboard - Rupa has both admin and user access */}
          {(user?.role === 'admin' || user?.email === 'rupasri7842@gmail.com') && (
            <Route path={"/admin"} component={AdminDashboard} />
          )}
          
          {/* User routes - available to all authenticated users */}
          <Route path={"/dashboard"} component={Dashboard} />
          <Route path={"/map"} component={MapView} />
          <Route path={"/booking/:slotId"} component={BookingPage} />
          <Route path={"/payment/:bookingId"} component={PaymentPage} />
          <Route path={"/history"} component={HistoryPage} />
          
          {/* Extend/Cancel routes - support multiple path formats */}
          <Route path={"/extend/:id"} component={ExtendCancelPage} />
          <Route path={"/extend-cancel"} component={ExtendCancelPage} />
          
          {/* Feedback route */}
          <Route path={"/feedback"} component={FeedbackPage} />
          
          {/* Profile/Settings routes - support multiple path formats */}
          <Route path={"/profile"} component={ProfileSettingsPage} />
          <Route path={"/settings"} component={ProfileSettingsPage} />
          
          {/* Active Session routes - support multiple path formats */}
          <Route path={"/active-session"} component={ActiveSessionPage} />
          <Route path={"/session"} component={ActiveSessionPage} />
        </>
      )}
      
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
