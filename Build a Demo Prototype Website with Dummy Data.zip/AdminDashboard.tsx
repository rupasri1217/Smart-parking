import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, LogOut, Plus, Edit2, Trash2, TrendingUp, Users, DollarSign, AlertTriangle, BarChart3 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminDashboard() {
  const { logout } = useAuth();
  const [, navigate] = useLocation();
  const [showNewLotForm, setShowNewLotForm] = useState(false);

  const { data: lots } = trpc.parkingLots.list.useQuery();
  const { data: violations } = trpc.analytics.violations.useQuery();
  const { data: bookings } = trpc.bookings.list.useQuery();
  const { data: payments } = trpc.payments.list.useQuery();

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const calculateTotalRevenue = () => {
    const actualRevenue = payments?.reduce((sum: number, p: any) => {
      return sum + (p.status === "completed" ? p.amount : 0);
    }, 0) || 0;
    // Add demo revenue for Rupa
    return actualRevenue > 0 ? actualRevenue : 200000;
  };

  const calculateAverageOccupancy = () => {
    if (!lots || lots.length === 0) return 0;
    const totalOccupancy = lots.reduce((sum: number, lot: any) => {
      return sum + ((lot.totalSlots - lot.availableSlots) / lot.totalSlots) * 100;
    }, 0);
    return Math.round(totalOccupancy / lots.length);
  };

  const getViolationColor = (type: string) => {
    switch (type) {
      case "overstay":
        return "bg-red-100 text-red-800";
      case "unauthorized_parking":
        return "bg-orange-100 text-orange-800";
      case "invalid_slot":
        return "bg-yellow-100 text-yellow-800";
      case "damage":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const totalBookings = bookings?.length || 0;
  const completedBookings = bookings?.filter((b: any) => b.status === "completed").length || 0;
  const activeBookings = bookings?.filter((b: any) => b.status === "active").length || 0;
  const totalSlots = lots?.reduce((sum: number, lot: any) => sum + lot.totalSlots, 0) || 0;
  const occupiedSlots = lots?.reduce((sum: number, lot: any) => sum + (lot.totalSlots - lot.availableSlots), 0) || 0;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-bold">FindMySlot Admin</h1>
          </div>
          <div className="flex items-center gap-4">
            <Badge>Admin</Badge>
            <Button variant="ghost" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Admin Dashboard</h2>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Parking Lots</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{lots?.length || 0}</p>
              <p className="text-xs text-gray-600 mt-1">Active locations</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Avg Occupancy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{calculateAverageOccupancy()}%</p>
              <p className="text-xs text-gray-600 mt-1">Across all lots</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Total Revenue
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">₹{Math.round(calculateTotalRevenue())}</p>
              <p className="text-xs text-gray-600 mt-1">All bookings</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Users className="w-4 h-4" />
                Total Bookings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{totalBookings}</p>
              <p className="text-xs text-gray-600 mt-1">{completedBookings} completed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Violations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {violations?.filter((v: any) => v.status !== "resolved").length || 0}
              </p>
              <p className="text-xs text-gray-600 mt-1">Pending</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="lots" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="lots">Parking Lots</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
            <TabsTrigger value="violations">Violations</TabsTrigger>
          </TabsList>

          {/* Parking Lots Tab */}
          <TabsContent value="lots" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Manage Parking Lots</CardTitle>
                    <CardDescription>Add, edit, or remove parking locations</CardDescription>
                  </div>
                  <Button onClick={() => setShowNewLotForm(!showNewLotForm)} className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add New Lot
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {showNewLotForm && (
                  <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-sm text-gray-600 mb-4">
                      New lot form would appear here. For demo, use the API directly.
                    </p>
                  </div>
                )}
                <div className="space-y-4">
                  {lots && lots.length > 0 ? (
                    lots.map((lot: any) => {
                      const occupancy = ((lot.totalSlots - lot.availableSlots) / lot.totalSlots) * 100;
                      return (
                        <div
                          key={lot.id}
                          className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="font-semibold text-gray-900">{lot.name}</h4>
                              <p className="text-sm text-gray-600">{lot.address}</p>
                            </div>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" className="gap-1">
                                <Edit2 className="w-3 h-3" />
                                Edit
                              </Button>
                              <Button size="sm" variant="outline" className="gap-1 text-red-600">
                                <Trash2 className="w-3 h-3" />
                                Delete
                              </Button>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                            <div>
                              <p className="text-xs text-gray-600">Price/Hour</p>
                              <p className="font-semibold">₹{lot.pricePerHour}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">Total Slots</p>
                              <p className="font-semibold">{lot.totalSlots}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">Available</p>
                              <p className="font-semibold">{lot.availableSlots}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">Occupancy</p>
                              <p className="font-semibold">{Math.round(occupancy)}%</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600">Status</p>
                              <Badge className={lot.isActive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                                {lot.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <p className="text-center py-8 text-gray-600">No parking lots found</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="mt-6">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Occupancy Trends</CardTitle>
                  <CardDescription>Real-time parking lot occupancy status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {lots && lots.map((lot: any) => {
                      const occupancy = ((lot.totalSlots - lot.availableSlots) / lot.totalSlots) * 100;
                      return (
                        <div key={lot.id}>
                          <div className="flex items-center justify-between mb-2">
                            <p className="text-sm font-semibold">{lot.name}</p>
                            <p className="text-sm text-gray-600">{Math.round(occupancy)}%</p>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all ${
                                occupancy < 30
                                  ? "bg-green-500"
                                  : occupancy < 70
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                              }`}
                              style={{ width: `${occupancy}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Revenue Summary</CardTitle>
                  <CardDescription>Daily and monthly revenue breakdown</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Total Revenue</p>
                      <p className="text-2xl font-bold">₹{Math.round(calculateTotalRevenue())}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Avg Per Booking</p>
                      <p className="text-2xl font-bold">
                        ₹{totalBookings > 0 ? Math.round(calculateTotalRevenue() / totalBookings) : 0}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total Slots</p>
                      <p className="text-2xl font-bold">{totalSlots}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Occupied Slots</p>
                      <p className="text-2xl font-bold">{occupiedSlots}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Bookings</CardTitle>
                <CardDescription>Latest booking activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {bookings && bookings.length > 0 ? (
                    bookings.slice(0, 15).map((booking: any) => (
                      <div
                        key={booking.id}
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                      >
                        <div>
                          <p className="font-semibold">Booking #{booking.id}</p>
                          <p className="text-sm text-gray-600">
                            {new Date(booking.startTime).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">₹{booking.totalPrice}</p>
                          <Badge
                            className={
                              booking.status === "completed"
                                ? "bg-green-100 text-green-800"
                                : booking.status === "active"
                                ? "bg-blue-100 text-blue-800"
                                : booking.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                            }
                          >
                            {booking.status}
                          </Badge>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center py-8 text-gray-600">No bookings found</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Violations Tab */}
          <TabsContent value="violations" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Parking Violations</CardTitle>
                <CardDescription>Track and manage parking violations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {violations && violations.length > 0 ? (
                    violations.slice(0, 15).map((violation: any) => (
                      <div
                        key={violation.id}
                        className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <p className="font-semibold text-gray-900">
                              Violation #{violation.id}
                            </p>
                            <p className="text-sm text-gray-600">
                              Booking #{violation.bookingId}
                            </p>
                          </div>
                          <Badge className={getViolationColor(violation.violationType)}>
                            {violation.violationType.replace("_", " ").toUpperCase()}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-gray-600">Fine Amount</p>
                            <p className="font-semibold">₹{violation.fineAmount}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">Status</p>
                            <Badge variant="outline">{violation.status}</Badge>
                          </div>
                          <div>
                            <p className="text-gray-600">Date</p>
                            <p className="text-xs">
                              {new Date(violation.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        {violation.description && (
                          <p className="text-sm text-gray-600 mt-2">{violation.description}</p>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-center py-8 text-gray-600">No violations recorded</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
