import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, LogOut, Heart, Clock, DollarSign, AlertCircle, Bell, History, MapIcon, Building2, Zap, Star } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<'user' | 'admin'>('user');

  const { data: bookings } = trpc.bookings.list.useQuery();
  const { data: notifications } = trpc.notifications.list.useQuery();
  const { data: favorites } = trpc.favorites.list.useQuery();
  const { data: payments } = trpc.payments.list.useQuery();

  const isRupa = user?.email === 'rupasri7842@gmail.com';

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const handleSwitchMode = () => {
    if (mode === 'user') {
      setMode('admin');
      navigate("/admin");
    } else {
      setMode('user');
      navigate("/dashboard");
    }
  };

  // If admin mode and user is admin, show admin dashboard
  if (mode === 'admin' && (user?.role === 'admin' || isRupa)) {
    navigate("/admin");
    return null;
  }

  const getBookingStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
      case "active":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "booking_confirmation":
        return "bg-blue-50 border-blue-200";
      case "reminder":
        return "bg-orange-50 border-orange-200";
      case "overstay_alert":
        return "bg-red-50 border-red-200";
      case "availability_update":
        return "bg-green-50 border-green-200";
      case "promotional":
        return "bg-purple-50 border-purple-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const activeBookings = bookings?.filter((b: any) => b.status === "active" || b.status === "confirmed") || [];
  const unreadNotifications = notifications?.filter((n: any) => !n.is_read) || [];
  const totalSpent = payments?.reduce((sum: number, p: any) => sum + (p.status === "completed" ? p.amount : 0), 0) || 0;

  // Check if this is a new user (Rupa gets dummy data, others get empty)
  const isNewUser = user?.email !== 'rupasri7842@gmail.com';

  // Dummy data for demo - only for Rupa
  const dummyActiveBooking = {
    id: 1001,
    slotId: 'A-101',
    status: 'active',
    paymentStatus: 'completed',
    startTime: new Date(Date.now() - 2 * 60 * 60 * 1000),
    endTime: new Date(Date.now() + 4 * 60 * 60 * 1000),
    totalPrice: 150,
    parkingLot: 'Downtown Plaza Parking'
  };

  const dummyFavorites = [
    { id: 1, name: 'Downtown Plaza Parking', location: '123 Main St', rating: 4.5, price: 50, isFavorite: true },
    { id: 2, name: 'Airport Terminal Parking', location: '456 Airport Rd', rating: 4.2, price: 40, isFavorite: true }
  ];

  // For new users, show empty states. For Rupa, show dummy data
  const displayActiveBookings = isNewUser ? [] : (activeBookings.length > 0 ? activeBookings : [dummyActiveBooking]);
  const displayFavorites = isNewUser ? [] : (favorites && favorites.length > 0 ? favorites : dummyFavorites);
  const displayTotalSpent = isNewUser ? 0 : (totalSpent > 0 ? totalSpent : 200);
  const displayNotifications = isNewUser ? [] : (unreadNotifications || []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-bold">FindMySlot</h1>
            {isRupa && (
              <Badge className="ml-4 bg-purple-600">Dual Access</Badge>
            )}
          </div>
          <div className="flex items-center gap-3">
            {isRupa && (
              <Button
                onClick={handleSwitchMode}
                className="bg-purple-600 hover:bg-purple-700 text-white font-semibold flex items-center gap-2"
              >
                <Zap className="w-4 h-4" />
                Switch to {mode === 'user' ? 'Admin' : 'User'} Mode
              </Button>
            )}
            <Button className="bg-blue-600 hover:bg-blue-700 text-white" onClick={() => navigate("/map")}>
              <MapIcon className="w-4 h-4 mr-2" />
              Find Parking
            </Button>
            <Button variant="ghost" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Welcome back, {user?.name || "User"}!</h2>
          <p className="text-gray-600 mt-2">Manage your parking bookings and view your history</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Active Bookings</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-600">{displayActiveBookings.length}</p>
              <p className="text-xs text-gray-600 mt-1">Currently active</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Notifications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-orange-600">{unreadNotifications.length}</p>
              <p className="text-xs text-gray-600 mt-1">Unread messages</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Heart className="w-4 h-4" />
                Favorites
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-red-600">{displayFavorites.length}</p>
              <p className="text-xs text-gray-600 mt-1">Saved locations</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Total Spent
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">₹{displayTotalSpent}</p>
              <p className="text-xs text-gray-600 mt-1">All time</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="active" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="active">Active Bookings</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
            <TabsTrigger value="history" onClick={() => navigate("/history")}>History</TabsTrigger>
            <TabsTrigger value="profile" onClick={() => navigate("/profile")}>Profile</TabsTrigger>
          </TabsList>

          {/* Active Bookings Tab */}
          <TabsContent value="active" className="mt-6">
            <div className="space-y-4">
              {displayActiveBookings.length > 0 ? (
                displayActiveBookings.map((booking: any) => (
                  <Card key={booking.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">Booking #{booking.id}</CardTitle>
                          <CardDescription>
                            {new Date(booking.startTime).toLocaleDateString()} at{" "}
                            {new Date(booking.startTime).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </CardDescription>
                        </div>
                        <Badge className={getBookingStatusColor(booking.status)}>
                          {booking.status.toUpperCase()}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-gray-600">Slot ID</p>
                          <p className="font-semibold">#{booking.slotId}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Amount</p>
                          <p className="font-semibold">₹{booking.totalPrice}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Duration</p>
                          <p className="font-semibold">
                            {Math.ceil(
                              (new Date(booking.endTime).getTime() -
                                new Date(booking.startTime).getTime()) /
                                (1000 * 60 * 60)
                            )}{" "}
                            hours
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Payment</p>
                          <Badge variant="outline">{booking.paymentStatus}</Badge>
                        </div>
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        <Button size="sm" variant="outline" onClick={() => navigate("/booking/" + booking.slotId)}>
                          View Details
                        </Button>
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white" onClick={() => navigate("/extend-cancel")}>
                          Extend
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 border-red-600" onClick={() => navigate("/extend-cancel")}>
                          Cancel
                        </Button>
                        <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => navigate("/active-session")}>
                          Start Session
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <p className="text-gray-600">No active bookings. Start by finding a parking spot!</p>
                    <Button className="mt-4 bg-blue-600 hover:bg-blue-700 text-white" onClick={() => navigate("/map")}>
                      Find Parking
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="mt-6">
            <div className="space-y-4">
              {displayNotifications.length > 0 ? (
                displayNotifications.map((notif: any) => (
                  <Card key={notif.id} className={`border-l-4 ${getNotificationColor(notif.type)}`}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-semibold">{notif.title}</p>
                          <p className="text-sm text-gray-600 mt-1">{notif.message}</p>
                          <p className="text-xs text-gray-500 mt-2">
                            {new Date(notif.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Bell className="w-4 h-4 text-gray-400" />
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <p className="text-gray-600">No new notifications</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Favorites Tab */}
          <TabsContent value="favorites" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {displayFavorites.length > 0 ? (
                displayFavorites.map((fav: any) => (
                <Card key={fav.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{fav.name}</CardTitle>
                        <CardDescription className="flex items-center gap-1 mt-1">
                          <MapPin className="w-3 h-3" />
                          {fav.location}
                        </CardDescription>
                      </div>
                      <Button size="sm" variant="ghost" className="text-red-600">
                        <Heart className="w-4 h-4 fill-red-600" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-sm text-gray-600">Rating</p>
                        <p className="font-semibold flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          {fav.rating}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Price/Hour</p>
                        <p className="font-semibold">₹{fav.price}</p>
                      </div>
                    </div>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white" onClick={() => navigate("/map")}>
                      Book Now
                    </Button>
                  </CardContent>
                </Card>
              ))
              ) : (
                <Card className="col-span-2">
                  <CardContent className="pt-6 text-center">
                    <p className="text-gray-600">No favorite locations yet. Add some from the map!</p>
                    <Button className="mt-4 bg-blue-600 hover:bg-blue-700 text-white" onClick={() => navigate("/map")}>
                      Browse Parking Lots
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
