import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin, LogOut, ArrowLeft } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import { toast } from "sonner";

export default function BookingPage() {
  const { logout } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/booking/:lotId");
  const lotId = params?.lotId ? parseInt(params.lotId) : 0;

  const [startDate, setStartDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endDate, setEndDate] = useState("");
  const [endTime, setEndTime] = useState("");
  const [selectedSlot, setSelectedSlot] = useState<any>(null);

  const { data: lot } = trpc.parkingLots.getById.useQuery({ id: lotId });
  const { data: slots } = trpc.parkingSlots.getByLotId.useQuery({ lotId });
  const createBookingMutation = trpc.bookings.create.useMutation();

  const availableSlots = useMemo(() => {
    return slots?.filter((s: any) => s.status === "available") || [];
  }, [slots]);

  const calculatePrice = () => {
    if (!startDate || !startTime || !endDate || !endTime || !lot) return 0;
    const start = new Date(`${startDate}T${startTime}`);
    const end = new Date(`${endDate}T${endTime}`);
    const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
    return Math.max(0, Math.ceil(hours) * parseFloat(lot.pricePerHour));
  };

  const handleBooking = async () => {
    if (!startDate || !startTime || !endDate || !endTime || !selectedSlot) {
      toast.error("Please fill in all fields and select a slot");
      return;
    }

    const start = new Date(`${startDate}T${startTime}`);
    const end = new Date(`${endDate}T${endTime}`);

    if (end <= start) {
      toast.error("End time must be after start time");
      return;
    }

    try {
      const result = await createBookingMutation.mutateAsync({
        slotId: selectedSlot.id,
        lotId,
        startTime: start,
        endTime: end,
        totalPrice: calculatePrice(),
      });
      const bookingId = (result as any)?.id || selectedSlot.id;
      toast.success("Booking created! Proceeding to payment...");
      setTimeout(() => {
        navigate(`/payment/${bookingId}`);
      }, 1500);
    } catch (error: any) {
      toast.error(error.message || "Failed to create booking");
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-bold">FindMySlot</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate("/dashboard")}>
              Dashboard
            </Button>
            <Button variant="ghost" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => navigate("/map")}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Map
        </Button>

        <h2 className="text-3xl font-bold text-gray-900 mb-8">Book Your Parking</h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Parking Lot Info */}
            {lot && (
              <Card>
                <CardHeader>
                  <CardTitle>{lot.name}</CardTitle>
                  <CardDescription>{lot.address}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Price/Hour</p>
                      <p className="text-lg font-semibold">₹{lot.pricePerHour}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Available Slots</p>
                      <p className="text-lg font-semibold">{lot.availableSlots}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total Slots</p>
                      <p className="text-lg font-semibold">{lot.totalSlots}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Date and Time Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Select Date & Time</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      min={new Date().toISOString().split("T")[0]}
                    />
                  </div>
                  <div>
                    <Label htmlFor="startTime">Start Time</Label>
                    <Input
                      id="startTime"
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      min={startDate || new Date().toISOString().split("T")[0]}
                    />
                  </div>
                  <div>
                    <Label htmlFor="endTime">End Time</Label>
                    <Input
                      id="endTime"
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Slot Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Select Parking Slot</CardTitle>
                <CardDescription>
                  {availableSlots.length} slots available
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-3">
                  {availableSlots.map((slot: any) => (
                    <button
                      key={slot.id}
                      onClick={() => setSelectedSlot(slot)}
                      className={`p-4 rounded-lg border-2 transition-all text-center font-semibold ${
                        selectedSlot?.id === slot.id
                          ? "border-blue-500 bg-blue-50 text-blue-900"
                          : "border-gray-200 hover:border-gray-300 text-gray-900"
                      }`}
                    >
                      <p className="text-sm">{slot.slotNumber}</p>
                      <Badge variant="outline" className="text-xs mt-2">
                        {slot.type}
                      </Badge>
                    </button>
                  ))}
                </div>
                {availableSlots.length === 0 && (
                  <p className="text-center py-8 text-gray-600">
                    No available slots at this time
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Summary */}
          <div>
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Parking Lot</p>
                  <p className="font-semibold">{lot?.name || "Not selected"}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Slot</p>
                  <p className="font-semibold">
                    {selectedSlot?.slotNumber || "Not selected"}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Duration</p>
                  <p className="font-semibold">
                    {startDate && startTime && endDate && endTime
                      ? `${startDate} ${startTime} - ${endDate} ${endTime}`
                      : "Not specified"}
                  </p>
                </div>
                <div className="border-t pt-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Price/Hour</span>
                    <span className="font-semibold">₹{lot?.pricePerHour || 0}</span>
                  </div>
                  <div className="flex justify-between mb-4">
                    <span className="text-gray-600">Total</span>
                    <span className="text-2xl font-bold text-blue-600">
                      ₹{calculatePrice()}
                    </span>
                  </div>
                </div>
                <Button
                  className="w-full"
                  onClick={handleBooking}
                  disabled={
                    !startDate ||
                    !startTime ||
                    !endDate ||
                    !endTime ||
                    !selectedSlot ||
                    createBookingMutation.isPending
                  }
                >
                  {createBookingMutation.isPending ? "Creating..." : "Proceed to Payment"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
