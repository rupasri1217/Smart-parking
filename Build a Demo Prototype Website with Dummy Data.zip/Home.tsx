import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { MapPin, Clock, CreditCard, ArrowRight, Building2, Users } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (isAuthenticated && user) {
    // Redirect to appropriate dashboard based on role
    if (user.role === 'admin') {
      navigate("/admin");
    } else {
      navigate("/dashboard");
    }
    return null;
  }

  const handleAdminLogin = () => {
    const url = getLoginUrl();
    window.location.href = url;
  };

  const handleUserLogin = () => {
    const url = getLoginUrl();
    window.location.href = url;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-6 h-6 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">FindMySlot</span>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Smart Parking Management
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Find, book, and manage parking spots effortlessly. For users seeking convenient parking or admins managing parking lots.
          </p>
        </div>

        {/* Login Options */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
          {/* User Login */}
          <div className="bg-white rounded-xl border-2 border-gray-200 p-8 hover:border-blue-400 hover:shadow-lg transition-all">
            <div className="flex justify-center mb-6">
              <div className="bg-blue-100 p-4 rounded-full">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-3 text-center">
              Find Parking
            </h2>
            <p className="text-gray-600 text-center mb-6">
              Browse available parking spots, book in advance, and manage your bookings easily.
            </p>
            <ul className="space-y-2 mb-8 text-sm text-gray-700">
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-green-600" />
                Real-time parking availability
              </li>
              <li className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-green-600" />
                Quick booking in seconds
              </li>
              <li className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-green-600" />
                Secure payments
              </li>
            </ul>
            <Button
              onClick={handleUserLogin}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2"
            >
              Login as User
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Admin Login */}
          <div className="bg-white rounded-xl border-2 border-gray-200 p-8 hover:border-purple-400 hover:shadow-lg transition-all">
            <div className="flex justify-center mb-6">
              <div className="bg-purple-100 p-4 rounded-full">
                <Building2 className="w-8 h-8 text-purple-600" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-3 text-center">
              Manage Parking
            </h2>
            <p className="text-gray-600 text-center mb-6">
              Create and manage your parking lot, track revenue, and monitor occupancy in real-time.
            </p>
            <ul className="space-y-2 mb-8 text-sm text-gray-700">
              <li className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-purple-600" />
                Create your parking lot
              </li>
              <li className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-purple-600" />
                Track revenue & earnings
              </li>
              <li className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-600" />
                Real-time analytics
              </li>
            </ul>
            <Button
              onClick={handleAdminLogin}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2"
            >
              Login as Admin
              <ArrowRight className="w-4 h-4" />
            </Button>
            <p className="text-xs text-gray-500 text-center mt-4">
              Demo: Use Rupa's account (rupasri7842@gmail.com)
            </p>
          </div>
        </div>

        {/* Features Section */}
        <section className="bg-white py-16 rounded-xl border border-gray-200 mb-16">
          <div className="max-w-4xl mx-auto px-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
              Why Choose FindMySlot?
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Real-Time Availability
                </h3>
                <p className="text-gray-600">
                  See live parking spot availability with instant updates
                </p>
              </div>

              <div className="text-center">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Easy Booking
                </h3>
                <p className="text-gray-600">
                  Book parking in just a few clicks with flexible duration
                </p>
              </div>

              <div className="text-center">
                <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CreditCard className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Secure Payments
                </h3>
                <p className="text-gray-600">
                  Multiple payment methods with secure wallet management
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            How It Works
          </h2>
          <div className="grid md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {[
              { num: "1", title: "Login", desc: "Sign in with your account" },
              { num: "2", title: "Browse", desc: "Find available parking spots" },
              { num: "3", title: "Book", desc: "Reserve your preferred slot" },
              { num: "4", title: "Park", desc: "Navigate and enjoy parking" }
            ].map((step, idx) => (
              <div key={idx} className="text-center">
                <div className="bg-blue-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-bold">
                  {step.num}
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-sm text-gray-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-400">
            &copy; 2026 FindMySlot. All rights reserved. | Smart Parking Management System
          </p>
        </div>
      </footer>
    </div>
  );
}
