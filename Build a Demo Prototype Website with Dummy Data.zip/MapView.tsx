import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { MapPin, Heart, LogOut, Menu, Search, Star, Users, Zap, Shield } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";

export default function MapView() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedLot, setSelectedLot] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [priceFilter, setPriceFilter] = useState<[number, number]>([0, 100]);

  const { data: parkingLots, isLoading } = trpc.parkingLots.list.useQuery();
  const { data: favorites } = trpc.favorites.list.useQuery();
  // const { data: reviews } = trpc.reviews.list.useQuery();
  const reviews: any[] = []; // Mock reviews data

  const isFavorite = useMemo(() => {
    if (!selectedLot || !favorites) return false;
    return favorites.some((fav: any) => fav.lotId === selectedLot.id);
  }, [selectedLot, favorites]);

  const addFavoriteMutation = trpc.favorites.add.useMutation();
  const removeFavoriteMutation = trpc.favorites.remove.useMutation();

  const filteredLots = useMemo(() => {
    if (!parkingLots) return [];
    return parkingLots.filter((lot: any) => {
      const matchesSearch =
        lot.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lot.address.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesPrice =
        parseFloat(lot.pricePerHour) >= priceFilter[0] &&
        parseFloat(lot.pricePerHour) <= priceFilter[1];
      return matchesSearch && matchesPrice;
    });
  }, [parkingLots, searchTerm, priceFilter]);

  const handleToggleFavorite = async () => {
    if (!selectedLot) return;
    try {
      if (isFavorite) {
        await removeFavoriteMutation.mutateAsync({ lotId: selectedLot.id });
      } else {
        await addFavoriteMutation.mutateAsync({ lotId: selectedLot.id });
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const getOccupancyPercentage = (lot: any) => {
    return ((lot.totalSlots - lot.availableSlots) / lot.totalSlots) * 100;
  };

  const getOccupancyColor = (percentage: number) => {
    if (percentage < 30) return "bg-green-100 text-green-800";
    if (percentage < 70) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const getAverageRating = (lotId: number) => {
    const lotReviews = reviews?.filter((r: any) => r.lotId === lotId) || [];
    if (lotReviews.length === 0) return 0;
    const sum = lotReviews.reduce((acc: number, r: any) => acc + r.rating, 0);
    return (sum / lotReviews.length).toFixed(1);
  };

  const getReviewCount = (lotId: number) => {